// Copyright 2026
//
// Licensed under the Apache License, Version 2.0.

#include "mppi_core/policies/jenga_grasp.hpp"

#include <stdexcept>
#include <utility>

#include <Eigen/Core>

namespace mppi_core {

JengaGraspConfig MakeDefaultJengaGraspConfig(std::size_t joint_dim) {
  if (joint_dim == 0) {
    throw std::invalid_argument(
        "MakeDefaultJengaGraspConfig: joint_dim is zero");
  }

  JengaGraspConfig config;
  config.mppi.horizon_steps = 20;
  config.mppi.num_rollouts = 128;
  config.mppi.action_dim = joint_dim;
  config.mppi.dt = 0.01;
  config.mppi.temperature = 1.0;
  config.mppi.random_seed = 1;
  config.mppi.action_lower_bound =
      Eigen::VectorXd::Constant(static_cast<Eigen::Index>(joint_dim), -0.015);
  config.mppi.action_upper_bound =
      Eigen::VectorXd::Constant(static_cast<Eigen::Index>(joint_dim), 0.015);
  config.mppi.action_noise_std =
      Eigen::VectorXd::Constant(static_cast<Eigen::Index>(joint_dim), 0.006);

  config.object = MakeJengaBlockObjectPrior();
  config.disturbances = MakeJengaGraspDisturbanceSet();
  config.grasp_stability_cost.closing_direction =
      Eigen::VectorXd::Ones(static_cast<Eigen::Index>(joint_dim));
  return config;
}

void JengaGrasp::Initialize(std::size_t joint_dim, JengaGraspConfig config) {
  if (joint_dim == 0) {
    throw std::invalid_argument("JengaGrasp::Initialize: joint_dim is zero");
  }
  if (config.mppi.action_dim == 0) {
    config.mppi.action_dim = joint_dim;
  }
  if (config.mppi.action_dim != joint_dim) {
    throw std::invalid_argument("JengaGrasp::Initialize: action_dim mismatch");
  }
  if (config.object.shape_type == ObjectShapeType::kUnknown) {
    config.object = MakeJengaBlockObjectPrior();
  }
  if (config.disturbances.empty()) {
    config.disturbances = MakeJengaGraspDisturbanceSet();
  }
  if (config.grasp_stability_cost.closing_direction.size() == 0) {
    config.grasp_stability_cost.closing_direction =
        Eigen::VectorXd::Ones(static_cast<Eigen::Index>(joint_dim));
  }

  object_ = config.object;
  disturbances_ = config.disturbances;
  model_ = std::make_shared<DeltaQReferenceRolloutModel>(joint_dim);

  optimizer_.Initialize(
      std::move(config.mppi), model_,
      std::make_shared<GraspStabilityCost>(config.grasp_stability_cost));
  initialized_ = true;
}

GraspCommand JengaGrasp::Update(const GraspObservation& observation) {
  if (!initialized_) {
    throw std::logic_error("JengaGrasp::Update: policy is not initialized");
  }

  GraspObservation policy_observation = observation;
  if (policy_observation.object == nullptr) {
    policy_observation.object = &object_;
  }
  if (policy_observation.tactile_disturbances.empty()) {
    policy_observation.tactile_disturbances = disturbances_;
  }
  return optimizer_.Update(policy_observation);
}

void JengaGrasp::Reset() {
  optimizer_.ResetNominalActions();
}

}  // namespace mppi_core
