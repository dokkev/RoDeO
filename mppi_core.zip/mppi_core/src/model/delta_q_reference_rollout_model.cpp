// Copyright 2026
//
// Licensed under the Apache License, Version 2.0.

#include "mppi_core/model/delta_q_reference_rollout_model.hpp"

#include <stdexcept>

namespace mppi_core {

DeltaQReferenceRolloutModel::DeltaQReferenceRolloutModel(std::size_t joint_dim)
    : joint_dim_(joint_dim) {
  if (joint_dim_ == 0) {
    throw std::invalid_argument(
        "DeltaQReferenceRolloutModel: joint_dim must be nonzero");
  }
}

void DeltaQReferenceRolloutModel::Step(
    const RobotRolloutState& state,
    const Eigen::Ref<const Eigen::VectorXd>& action,
    const RolloutContext& context, double dt,
    RobotRolloutState* next_state) const {
  (void)context;
  if (next_state == nullptr) {
    throw std::invalid_argument(
        "DeltaQReferenceRolloutModel::Step: next_state is null");
  }
  if (dt <= 0.0) {
    throw std::invalid_argument(
        "DeltaQReferenceRolloutModel::Step: dt must be positive");
  }
  if (state.q.size() != static_cast<Eigen::Index>(joint_dim_) ||
      action.size() != static_cast<Eigen::Index>(joint_dim_)) {
    throw std::invalid_argument(
        "DeltaQReferenceRolloutModel::Step: dimension mismatch");
  }

  next_state->q = state.q + action;
  next_state->v = action / dt;
}

}  // namespace mppi_core
