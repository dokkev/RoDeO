// Copyright 2026
//
// Licensed under the Apache License, Version 2.0.

#pragma once

#include <cstddef>

#include <Eigen/Core>

#include "mppi_core/grasp_types.hpp"

namespace mppi_core {

struct RobotRolloutState {
  Eigen::VectorXd q;
  Eigen::VectorXd v;

  void Resize(std::size_t nq, std::size_t nv) {
    q.setZero(static_cast<Eigen::Index>(nq));
    v.setZero(static_cast<Eigen::Index>(nv));
  }
};

struct RolloutContext {
  const NariTouchState* tactile{nullptr};
  const ObjectPrior* object{nullptr};
  const TactileDisturbanceSet* tactile_disturbances{nullptr};
  const RobotRolloutState* measured_state{nullptr};
  const RobotRolloutState* initial_reference_state{nullptr};
  bool has_gravity_context{false};
  Eigen::Vector3d gravity_in_sensor_frame{Eigen::Vector3d::Zero()};
};

class RolloutModelBase {
 public:
  virtual ~RolloutModelBase() = default;

  virtual std::size_t actionDim() const = 0;

  virtual void Step(const RobotRolloutState& state,
                    const Eigen::Ref<const Eigen::VectorXd>& action,
                    const RolloutContext& context, double dt,
                    RobotRolloutState* next_state) const = 0;
};

}  // namespace mppi_core
