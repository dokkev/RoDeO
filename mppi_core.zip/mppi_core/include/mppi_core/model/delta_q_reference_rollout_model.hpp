// Copyright 2026
//
// Licensed under the Apache License, Version 2.0.

#pragma once

#include <cstddef>

#include "mppi_core/model/rollout.hpp"

namespace mppi_core {

class DeltaQReferenceRolloutModel final : public RolloutModelBase {
 public:
  explicit DeltaQReferenceRolloutModel(std::size_t joint_dim);

  std::size_t actionDim() const override { return joint_dim_; }

  void Step(const RobotRolloutState& state,
            const Eigen::Ref<const Eigen::VectorXd>& action,
            const RolloutContext& context, double dt,
            RobotRolloutState* next_state) const override;

 private:
  std::size_t joint_dim_{0};
};

}  // namespace mppi_core
